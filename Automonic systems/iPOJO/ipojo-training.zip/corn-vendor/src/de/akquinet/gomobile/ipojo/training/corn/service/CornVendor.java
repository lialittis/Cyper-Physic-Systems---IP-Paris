package de.akquinet.gomobile.ipojo.training.corn.service;


public interface CornVendor {

    public void getCorn();

}
